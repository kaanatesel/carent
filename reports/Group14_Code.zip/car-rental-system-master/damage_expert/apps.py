from django.apps import AppConfig


class DamageExpertConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'damage_expert'
